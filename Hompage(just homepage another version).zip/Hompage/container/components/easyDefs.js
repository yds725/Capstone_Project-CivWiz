export default `Prejudiced thoughts and discriminatory actions based on differences in physical, mental, and/or emotional ability; usually that of able-bodied / minded persons against people with illness, disabilities, or less developed skills / talents.
The extent to which a facility is readily approachable and usable by individuals with disabilities, particularly such areas as the personnel office, worksite and public areas. 
Being held responsible for one’s actions or words, and for the impact those words and actions have on other people
Any action or campaign to promote, impede, or direct social, political, economic, or environmental change, or stasis`
