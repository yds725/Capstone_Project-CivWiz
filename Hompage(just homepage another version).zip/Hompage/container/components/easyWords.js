export default `ableism
accessibility
accountability
activism`