export default `cat
four
right
eleven
potato
six
black`
