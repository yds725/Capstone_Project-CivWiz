/**
 * CivWiz Capstone Project
 * Word Scramble Game Module 
 **/

import React, { Component } from 'react';
import {AppRegistry, StyleSheet, Text, View, TouchableHighlight, ActivityIndicator, TextInput, Button, Alert, ImageBackground,TouchableOpacity, Image} from 'react-native';
import colors from './components/Colors.js'
import GameData from './components/root.js'

export default class WordScramble extends Component {
  constructor(props) {
    super(props)
    this.gameData = new GameData()

    this.state = {
      currentWord: null, scrambledWord: null,
      answerCorrect: false,
      text: '',
      definition: null
    }
  }

  componentDidMount() {
    this.newWord()
  }

  componentWillUnmount() {
    if (this.interval) {
      clearInterval(this.interval)
      this.interval = null
    }
  }

  newWord() {
    const { gameData: g } = this

    const num = g.getSize()
    const i = Math.floor(Math.random() * num)
    const currentWord = g.getWord(i)
    const currentDef = g.getDefinition(i) //Get new def when getting new word
    const scrambledWord = g.scramble(currentWord)
    if(currentWord != scrambledWord){
      this.setState({
        currentWord,
        scrambledWord,
        currentDef
      })
    } else {
      this.newWord()
    }
  }

  handleSubmit(event) {
    const { text, currentWord } = this.state
    if (text.toLowerCase() === currentWord.toLowerCase()) {
      this.setState({
        text: '',
        scrambledWord: null,
        answerCorrect: true,
      })
    } else {
      this.setState({ text: '' })
      Alert.alert('Try Again')
    }
  }

  render() {
    const { currentWord, scrambledWord, text, currentDef } = this.state
    if (currentWord == null) return (<View />)
    return (
      <View style={{flex:1}}>
        <View style={styles.top}>

          <ImageBackground 
            source={require('./assets/userprofile_bg.png')} 
            style={{
              width: '100%',
              height: '100%',
              alignSelf: 'flex-start',
              //flexDirection: 'row',
              //alignItems: 'center'
            }}>
            
            <TouchableOpacity onPress={() => console.log("menu")}>
                      <Image 
                        source={require('./assets/scramble_menu_default.png')}
                        style={{
                          marginTop:'8%',
                          marginLeft: '5%',
                        }}/>
            </TouchableOpacity>

            <View style={styles.pageContainer}>
              <Text style={styles.scrambledContainer}>
                {scrambledWord || currentWord.toUpperCase()}
              </Text>

              <TextInput
                placeholder={'Answer'}
                autoCapitalize={"characters"}
                style={styles.inputContainer}
                maxLength={currentWord.length}
                onChangeText={text => this.setState({ text })}
                value={text}
                autoCorrect={false}
                returnKeyType="go"
                onSubmitEditing={e => this.handleSubmit(e)}/>

                {scrambledWord == null ? <Button title="Correct!" color='dodgerblue' onPress={e => this.newWord()} /> : null}

              <Text style={styles.definitionContainer}>
                {/*Display the definition for the word*/}
                {currentDef}
              </Text>
            </View>

          </ImageBackground>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  top:{
    /*flex: 1,
    backgroundColor: 'dodgerblue',
    flexDirection: 'row',
    height:300*/
  },
  pageContainer:{
    /*//alignContent: 'center',
    flex: 1,
    flexDirection: 'row',*/
    flex: 1,
    alignItems: 'center',
  },
  scrambledContainer: {
    flex: 1,
    /*marginTop: '40%',
    color: colors.floralwhite,
    fontSize: 35,
    fontFamily: 'sans-serif-medium',
    textAlign: 'center'*/
    fontSize: 35,
    fontFamily: 'sans-serif-medium',
    color: 'white',
    marginTop: 15
  },
  inputContainer: {
    //flex: 2,

    backgroundColor: 'grey',
    borderColor: 'white',
    borderWidth: 3,
    color: 'white',
    fontSize: 25,
    fontFamily: 'sans-serif-medium',
    textAlign: 'center',

    width: '75%',
    height: '10%',
    borderRadius: 10
  },
  definitionContainer:{
    flex: 3,

    color: 'pink',
    fontSize: 15,
    fontFamily: 'sans-serif-medium',
    borderColor: '#f4bc42',
    backgroundColor: '#20b2aa',
    borderWidth: 5,
    textAlign: 'center', /*THIS MIGHT BE AN ISSUE*/

    marginHorizontal: 20,
    marginVertical: 20,
    justifyContent: 'space-around',
    padding: 10,
    borderRadius: 10,
  },
});

AppRegistry.registerComponent('Scrambled', () => Scrambled);