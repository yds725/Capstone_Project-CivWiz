import React, { Component } from 'react';
import { ImageBackground, View, StyleSheet, Alert, Image, StatusBar, Dimensions} from 'react-native';
import {Container, Content, Button, Text, Card, Icon, Body, Left, Right, CardItem, Thumbnail, Footer, FooterTab} from 'native-base';
import { Constants } from 'expo';
import { Font } from 'expo';
import { icons } from '@expo/vector-icons/FontAwesome5';
const deviceHeight = Dimensions.get("window").height;

export default class HomePage extends Component {
  _onPressWordScramble = () => {
    this.props.navigation.navigate('word_scramble');
  };

  _onPressTrivia = () => {
    this.props.navigation.navigate('trivia');
  };

  render() {
    return (
          <Container>
          
          <ImageBackground source={require('./images/userprofile_bg.png')} style={styles.imageContainer}>
          <Content>
          <Card transparent>
           <CardItem style={styles.topContainer}>
             <Left>
                <Thumbnail source={require('./images/male.png')} />
                <Body>
                  <Text>Username</Text>
                  <Text note>EmailAddress</Text>
                </Body>
              </Left>
           </CardItem>
           <CardItem bordered style={styles.cardContainer} >
              <Body>
                <Text>
                  NativeBase is a free and open source framework that enable
                  developers to build
                  high-quality mobile apps using React Native iOS and Android
                  apps
                  with a fusion of ES6.
                </Text>
              </Body>
           </CardItem>
          </Card>

          <Card transparent>
            <CardItem  style={styles.cardContainer}>
              <Left>
              <Thumbnail source={require('./images/W.png')} />
               <Body>
                  <Text>Word Scramble</Text>
                  <Text note>Statistics</Text>
                </Body>
              </Left>
              <Right>
                <Button rounded success
              onPress={this._onPressWordScramble}>
            <Text>Play Scramble</Text>
            </Button>
              </Right>
            </CardItem>
            <CardItem bordered style={styles.cardContainer}>
              <Body>
                <Text>
                  NativeBase is a free and open source framework that enable
                  developers to build
                  high-quality mobile apps using React Native iOS and Android
                  apps
                  with a fusion of ES6.
                </Text>
              </Body>
           </CardItem>
          </Card>

           <Card transparent>
            <CardItem style={styles.cardContainer}>
              <Left>
              <Thumbnail source={require('./images/T.png')} />
               <Body>
                  <Text>Trivia</Text>
                  <Text note>Statistics</Text>
                </Body>
              </Left>
              <Right>
                <Button rounded warning
                onPress={this._onPressTrivia}>
          <Text>Play Trivia</Text>
            </Button>
              </Right>
            </CardItem>
            <CardItem bordered style={styles.cardContainer}>
              <Body>
                <Text>
                  NativeBase is a free and open source framework that enable
                  developers to build
                  high-quality mobile apps using React Native iOS and Android
                  apps
                  with a fusion of ES6.
                </Text>
              </Body>
           </CardItem>
          </Card> 
        </Content>
       </ImageBackground>
     <Footer>
     <FooterTab>
        <Button block success>
              <Text>Word Scramble</Text>
        </Button>
        <Button block warning>
              <Text>Trivia</Text>
            </Button>
      </FooterTab>
     </Footer>
     
    </Container>
    );
  }
}

var styles = StyleSheet.create({
  imageContainer: {
    flex: 1,
    width: null,
    height: null
  },
  cardContainer: {
    flex: 1,
    //marginTop: deviceHeight / 8,
    backgroundColor: "transparent"
  },
   topContainer: {
    flex: 1,
    marginTop: deviceHeight / 30,
    backgroundColor: "transparent"
  },  
  logo: {
    position: "absolute",
    //left: Platform.OS === "android" ? 40 : 50,
    //top: Platform.OS === "android" ? 35 : 60,
    width: 280,
    height: 100
  },
  text: {
    color: "#D8D8D8",
    bottom: 6,
    marginTop: 5
  }
});