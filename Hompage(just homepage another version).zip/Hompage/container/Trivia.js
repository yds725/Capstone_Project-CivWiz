import React, { Component } from 'react';
import { Easing, Animated, ImageBackground, Text, View, StyleSheet, Button, Alert, Image, TouchableOpacity} from 'react-native';
import { Constants } from 'expo';
import { Vibration} from 'react-native'
//import Questions from './Questions';
import TimerCountdown from "react-native-timer-countdown";

//import * as QuestionsData from './Questions';
const DURATION = 10000;
const PATTERN = [1000, 2000, 3000];


export default class Trivia extends Component {

    constructor() {
        super();
        this.stopAnimation= false;
        this.animatedValue = new Animated.Value(0);
        this.state = {
              questions:[
              {
                  Question: "In inches, how high is a table-tennis net?",
                  A: "There is no standard",
                  B: "4 inches",
                  C: "5 inches",
                  D: "6 inches",
                  Answer: "D"
                },
                {
                  Question: "Which Italian football team has the nickname I Lupi which translates as The Wolves?",
                  A: "Fiorentina",
                  B: "Parma",
                  C: "Roma",
                  D: "Genoa",
                  Answer: "C"
                },
                {
                  Question: "Whose ear did Mike Tyson bite in 1997?",
                  A: "Edward Teech",
                  B: "Rashad Evans",
                  C: "Evander Hockle",
                  D: "Evander Holyfield",
                  Answer: "D"
                },
                {
                  Question: "In a rugby scrum, which player is responsible for controlling the ball with their feet inside the scrum?",
                  A: "Fullback",
                  B: "Tighthead Prop",
                  C: "Hooker",
                  D: "Rowler",
                  Answer: "D"
                },
                {
                  Question: "How many times has the host nation won the football World Cup?",
                  A: "3",
                  B: "4",
                  C: "5",
                  D: "6",
                  Answer: "D"
                },
                {
                  Question: "How deep is the atmosphere that surrounds the Earth?",
                  A: "About 50 miles",
                  B: "About 100 miles",
                  C: "About 400 miles",
                  D: "About 1000 miles",
                  Answer: "C"
                },
                {
                  Question: "The currents of which ocean produce the El Nino effect?",
                  A: "Indian",
                  B: "Atlantic",
                  C: "Pacific",
                  D: "Arctic",
                  Answer: "C"
                },
                {
                  Question: "What is the highest point in Antarctica?",
                  A: "Mount Coman",
                  B: "Mount Erebus",
                  C: "Mount Jackson",
                  D: "Mount Mino",
                  Answer: "C"
                },
                {
                  Question: "Which country shares borders with Egypt, Jordan, Lebanon and Syria?",
                  A: "Iraq",
                  B: "Israel",
                  C: "Oman",
                  D: "Saudi Arabia",
                  Answer: "B"
                },
                {
                  Question: "Which river flows through the Polish capital, Warsaw?",
                  A: "Neisse",
                  B: "Oder",
                  C: "Vistula",
                  D: "Warta",
                  Answer: "C"
                },
                {
                  Question: "How many chambers does a normal human heart have?",
                  A: "2",
                  B: "4",
                  C: "6",
                  D: "8",
                  Answer: "B"
                },
                {
                  Question: "In human body, where is the humerus bone?",
                  A: "Upper leg",
                  B: "Lower leg",
                  C: "Upper arm",
                  D: "Lower arm",
                  Answer: "C"
                },
                {
                  Question: "Which chemist is best known for the process of heating liquids to destroy harmful organisms?",
                  A: "Michael Faraday",
                  B: "Primo Levi",
                  C: "Alfred Nobel",
                  D: "Louis Pasteur",
                  Answer: "D"
                },
                {
                  Question: "What colour does blue litmus paper turn under acidic conditions?",
                  A: "Black",
                  B: "Green",
                  C: "Red",
                  D: "Yellow",
                  Answer: "C"
                },
                {
                  Question: "What is created in space upon the collapse of a neutron star?",
                  A: "Asteroids",
                  B: "Black Hole",
                  C: "Galaxy",
                  D: "Solar System",
                  Answer: "B"
                },
                {
                  Question: "Which director won a special achievement Oscar for his work on the 1995 Pixar film 'Toy Story'",
                  A: "Brad Bird",
                  B: "Mike Judge",
                  C: "John Lasseter",
                  D: "Trey Parker",
                  Answer: "C"
                },
                {
                  Question: "What is circling the actual golden globe on the Golden Globe statuette?",
                  A: "A strip of film",
                  B: "An airplane",
                  C: "A movie ticket",
                  D: "A film script",
                  Answer: "A"
                },
                {
                  Question: "The 2008 film The Curious Case of Benjamin Button is based on the short story by which author?",
                  A: "Isaac Asimov",
                  B: "Roald Dahl",
                  C: "Daphne du Maurier",
                  D: "F Scott Fitzgerald",
                  Answer: "D"
                },
                {
                  Question: "What nationality is Thomas Keneally, whose novel Schindler's Ark became the 1993 film Schindler's List?",
                  A: "American",
                  B: "Australian",
                  C: "Irish",
                  D: "South African",
                  Answer: "B"
                },
                {
                  Question: "The 1984 film Children of the Corn is based on a short story from which Stephen King collection?",
                  A: "Blood and Smoke",
                  B: "Different Seasons",
                  C: "Night Shift",
                  D: "Skeleton Crew",
                  Answer: "C"
                },
                {
                  Question: "Which religious leader was assassinated on 4th April 1968?",
                  A: "Jesse Jackson",
                  B: "Martin Luther King",
                  C: "Mother Theresa",
                  D: "Pope Paul",
                  Answer: "B"
                },
                {
                  Question: "What nationality was the philosopher and mathematician, Pythagoras?",
                  A: "Greek",
                  B: "Persian",
                  C: "Roman",
                  D: "Trojan",
                  Answer: "A"
                },
                {
                  Question: "Between 1918 and 1939, how did people refer to World War 1?",
                  A: "The Big War",
                  B: "The Continental War",
                  C: "The European War",
                  D: "The Great War",
                  Answer: "D"
                },
                {
                  Question: "What was the name of the regime in Germany between 1918 and 1933?",
                  A: "North German Confederation",
                  B: "Second German Empire",
                  C: "Third Reich",
                  D: "Weimar Republic",
                  Answer: "D"
                },
                {
                  Question: "How was the 'Kingdom of Serbs, Croats and Slovenes' re-named in 1929?",
                  A: "Bulgaria",
                  B: "Czechoslovakia",
                  C: "Romania",
                  D: "Yugoslavia",
                  Answer: "D"
                },
                {
                  Question: "Pablo Picasso was born in 1881 in which Spanish city?",
                  A: "Madrid",
                  B: "Malaga",
                  C: "Marbella",
                  D: "Murcia",
                  Answer: "B"
                },
                {
                  Question: "The English artist George Stubbs, who died in 1806, is best remembered for his paintings of what?",
                  A: "Cats",
                  B: "Deer",
                  C: "Dogs",
                  D: "Horses",
                  Answer: "D"
                },
                {
                  Question: "Hans Holbein the Younger was criticized by Henry VIII for painting a flattering portrait of whom?",
                  A: "Anne Boleyn",
                  B: "Anne of Cleves",
                  C: "Catherine Howard",
                  D: "Jane Seymour",
                  Answer: "B"
                },
                {
                  Question: "Leonardo da Vinci's famous Mona Lisa was painted on what type of wood?",
                  A: "Elm",
                  B: "Mahogany",
                  C: "Poplar",
                  D: "Walnut",
                  Answer: "C"
                },
                {
                  Question: "How did Vincent van Gogh die?",
                  A: "He gassed himself",
                  B: "He poisoned himself",
                  C: "He shot himself",
                  D: "He stabbed himself",
                  Answer: "C"
                }
              ],
              currentQuestion: " ",
              questionCount: 0,
              correctAnswerCount: 0,
              wrongAnswer: '',
              questionfront: 0,

          }
    }

   
    componentWillMount() {
      this.generateQuestions();
    }

    generateQuestions() {
       qs = this.state.questions;
        console.log(qs[0]);
        this.setState({ currentQuestion: qs[0].Question });
        this.setState({ questionCount: 0 });
        if(qs[0].Question.length > 45){
          this.setState({ questionfront: 20 });
        }else{
          this.setState({ questionfront: 40 });
        }
    } 

    answerQuestion(choice) {
        this.setState({ 'correctAnswer': this.state.questions[this.state.questionCount].Answer });
        
        if (choice === this.state.questions[this.state.questionCount].Answer) {
            Alert.alert('Correct!');
            let correctAnswerCount = this.state.correctAnswerCount;
            let newCorrectAnswerCount = correctAnswerCount + 1;
            this.setState({ 'correctAnswerCount': newCorrectAnswerCount });
        }else if(choice ===" "){
            Alert.alert('Time out!!!');
        }else {
            Alert.alert('That is Wrong:(');
            this.setState({ 'wrongAnswer': choice });
        }

        let questionCount = this.state.questionCount;
        questionCount++;
        this.setState({ 'questionCount': questionCount });
        setTimeout(() => {
                this.setState({ 'currentQuestion': this.state.questions[questionCount].Question });
                this.setState({ 'wrongAnswer': '' });
                this.setState({ 'correctAnswer': '' });
                if(this.state.questions[questionCount].Question.length > 45){
                  this.setState({ questionfront: 30 });
                }else{
                  this.setState({ questionfront: 40 });
                }
                this.stopVibration();
                this.stopAnimation= true;
                
        }, 500);
        
    }

    skipQuestion() {
        this.setState({ 'correctAnswer': this.state.questions[this.state.questionCount].Answer });
        let questionCount = this.state.questionCount;
        questionCount++;
        this.setState({ 'questionCount': questionCount });
        setTimeout(() => {
                this.setState({ 'currentQuestion': this.state.questions[questionCount].Question });
                this.setState({ 'wrongAnswer': '' });
                this.setState({ 'correctAnswer': '' });
                if(this.state.questions[questionCount].Question.length > 45){
                  this.setState({ questionfront: 30 });
                }else{
                  this.setState({ questionfront: 40 });
                }
                this.stopVibration();
                this.stopAnimation= true;
                
        }, 500);
        
    }

    startShaking(){
      this.stopAnimation= false;
    }


    startVibration(){
      // Device Will Vibrate for 10 seconds.
      Vibration.vibrate(PATTERN) ;
    }

    stopVibration(){
      // Stop Vibration.
      Vibration.cancel();
    }

    handleAnimation(){
        console.log(this.stopAnimation);
        // Animation consists of a sequence of steps
        Animated.sequence([
          // start rotation in one direction (only half the time is needed)
          Animated.timing(this.animatedValue, {toValue: 1.0, duration: 150, easing: Easing.bounce, useNativeDriver: true}),
          // rotate in other direction, to minimum value (= twice the duration of above)
          Animated.timing(this.animatedValue, {toValue: -1.0, duration: 300, easing: Easing.bounce, useNativeDriver: true}),
          // return to begin position
          Animated.timing(this.animatedValue, {toValue: 0.0, duration: 150, easing: Easing.bounce, useNativeDriver: true})
        ]).start(() => {
        if(this.stopAnimation === false) {

          this.handleAnimation();
        }
      }); 
    }



    render() {
    return (
      <View style={{flex:1}}>
        <View style={styles.top}>
          <ImageBackground
          source={require('./trivia_pc/userprofile_bg.png')}
          style={{
            width: '100%',
            height: '100%',
            flexDirection: 'row',
            alignSelf: 'flex-start'
          }}>

          <View style={styles.topCenterContainer}>

          <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={() => console.log("menu")}>
                  <Image 
                    source={require('./trivia_pc/scramble_menu_default.png')}
                    style={{
                      marginTop:'40%',
                      marginLeft: '20%', 
                    }}/>
           </TouchableOpacity>
           <TouchableOpacity onPress={() => this.skipQuestion()}>
                  <Image 
                    source={require('./trivia_pc/skip.png')}
                    style={{
                      marginLeft: '60%',
                      marginTop: 50,
                      width: 63, 
                      height: 63
                    }}/>
           </TouchableOpacity>
           </View>
          
            <Animated.Text style={{
              marginLeft: '7%',
              marginRight: '7%',
              marginBottom: '5%',
              fontSize: this.state.questionfront,
              color: 'white',
              transform: [{
                translateY: this.animatedValue.interpolate({
                  inputRange: [-2, 0],
                  outputRange: [-10, 0]
                })
              }]
            }}>
            
              {this.state.currentQuestion}
            </Animated.Text>

           


            <View style={styles.middleContainer}>

            <TimerCountdown
              initialMilliseconds={1000 * 30}
              onExpire={() => this.answerQuestion(" ")}
              formatMilliseconds={(milliseconds) => {
                const remainingSec = Math.round(milliseconds / 1000);
                const seconds = parseInt((remainingSec % 60).toString(), 10);
                const minutes = parseInt(((remainingSec / 60) % 60).toString(), 10);
                
                const s = seconds < 10 ? '0' + seconds : seconds;
                const m = minutes < 10 ? '0' + minutes : minutes;
                return m + ':' + s;
              }}
              allowFontScaling={true}
              style={{ fontSize: 28,
                color: '#ffa500',
              }}
            />
            
             </View>
            

            <View style={styles.lowerContainer}>

           <TouchableOpacity style={styles.qpJokerView} onPress={() => this.answerQuestion("A")}>
                  <Text style={{
                  width: '80%',
                  marginLeft: '10%',
                  fontSize: 24,
                  color: 'pink',
                }}>
                  A. {this.state.questions[this.state.questionCount].A}
                </Text>
           </TouchableOpacity>

           <Text style={{
                  marginTop: '5%',
                }}>
            </Text>

           <TouchableOpacity style={styles.qpJokerView} onPress={() => this.answerQuestion("B")}>
           <Text style={{
                  width: '80%',
                  marginLeft: '10%',
                  fontSize: 24,
                  color: 'pink',
                }}>
                  B. {this.state.questions[this.state.questionCount].B}
                </Text>
           </TouchableOpacity>

           <Text style={{
                  marginTop: '5%',
                }}>
            </Text>

           <TouchableOpacity style={styles.qpJokerView} onPress={() => this.answerQuestion("C")}>
                  <Text style={{
                  width: '80%',
                  marginLeft: '10%',
                  fontSize: 24,
                  color: 'pink',
                }}>
                  C. {this.state.questions[this.state.questionCount].C}
                </Text>
           </TouchableOpacity>

           <Text style={{
                  marginTop: '5%',
                }}>
            </Text>
          

           <TouchableOpacity style={styles.qpJokerView} onPress={() => this.answerQuestion("D")}>
                  <Text style={{
                  width: '80%',
                  marginLeft: '10%',
                  fontSize: 24,
                  color: 'pink',
                }}>
                  D. {this.state.questions[this.state.questionCount].D}
                </Text>
           </TouchableOpacity>

           <Text style={{
                  marginBottom: '5%',
                }}>

            </Text>

            
           </View>
          </View>

          </ImageBackground>

          <TimerCountdown
              initialMilliseconds={1000 * 20}
              onExpire={() => this.startVibration()}
              formatMilliseconds={(milliseconds) => {
                const remainingSec = Math.round(milliseconds / 1000);
                const seconds = parseInt((remainingSec % 60).toString(), 10);
                const minutes = parseInt(((remainingSec / 60) % 60).toString(), 10);
                
                const s = seconds < 10 ? '0' + seconds : seconds;
                const m = minutes < 10 ? '0' + minutes : minutes;
                return m + ':' + s;
              }}
              allowFontScaling={true}
              style={{ fontSize: 28,
                color: '#ffa500',
              }}
            />

            <TimerCountdown
              initialMilliseconds={1000 * 20}
              onExpire={() => this.handleAnimation()}
              formatMilliseconds={(milliseconds) => {
                const remainingSec = Math.round(milliseconds / 1000);
                const seconds = parseInt((remainingSec % 60).toString(), 10);
                const minutes = parseInt(((remainingSec / 60) % 60).toString(), 10);
                
                const s = seconds < 10 ? '0' + seconds : seconds;
                const m = minutes < 10 ? '0' + minutes : minutes;
                return m + ':' + s;
              }}
              allowFontScaling={true}
              style={{ fontSize: 28,
                color: '#ffa500',
              }}
            />

            <TimerCountdown
              initialMilliseconds={1000 * 19}
              onExpire={() => this.startShaking()}
              formatMilliseconds={(milliseconds) => {
                const remainingSec = Math.round(milliseconds / 1000);
                const seconds = parseInt((remainingSec % 60).toString(), 10);
                const minutes = parseInt(((remainingSec / 60) % 60).toString(), 10);
                
                const s = seconds < 10 ? '0' + seconds : seconds;
                const m = minutes < 10 ? '0' + minutes : minutes;
                return m + ':' + s;
              }}
              allowFontScaling={true}
              style={{ fontSize: 28,
                color: '#ffa500',
              }}
            />


      </View>

        </View>

    );
  }

}


const styles = StyleSheet.create({
  top: {
    flex: 1,
    backgroundColor: 'dodgerblue',
    flexDirection: 'row',
    height:300
  },
  topCenterContainer:{
    flex: 1,
  },
  lowerContainer:{
    flex: 1,
    marginBottom:'15%',
    alignItems: 'center',
    justifyContent: 'center',
    height:400,
  },
  middleContainer:{
    flex: 1,
    marginLeft:'7%',
    flexDirection: 'row',

  },
  buttonContainer:{
    flex: 1,
    flexDirection: 'row',
    height: 200,
  },
  qpJokerView: {
        backgroundColor: '#20b2aa',
        borderWidth: 3,
        borderColor: '#f4bc42',
        height: 50,
        width: 300,
        borderRadius: 10,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 5,
        shadowColor: 'rgba(0, 0, 0, 0.1)',
        shadowOpacity: 1,
        shadowRadius: 10,
        shadowOffset: { width: 1, height: 10 }
    },

});



