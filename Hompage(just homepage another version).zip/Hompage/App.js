import React from 'react';
import { createStackNavigator, createAppContainer } from 'react-navigation';
import HomePage from "./container/HomePage";
import WordScramble from "./container/WordScramble";
import Trivia from "./container/Trivia";

const App = createStackNavigator(
  {
    home: { screen: HomePage },
    word_scramble : { screen: WordScramble},
    trivia : {screen: Trivia}
  }
);
export default createAppContainer(App);
